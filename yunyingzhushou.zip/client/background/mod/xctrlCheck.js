export default function() {
  //  chrome.webRequest.onBeforeRequest.addListener(
  //    function(details) {
  //      debugger;
  //    },
  //    {urls: ["*://www.taobao.com/go/rgn/sys/xctrl/dispatch.php"]},
  //    ["blocking"]);
}
