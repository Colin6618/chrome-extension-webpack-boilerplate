// todo
// var details = {
//   tabId: tab.id,
//   path: '../img/youdianlihai.png'
// };
// chrome.pageAction.setIcon(details);
